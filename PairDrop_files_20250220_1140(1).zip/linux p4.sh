#!/bin/bash
echo "Enter your name:"
read user_name
echo "Hello, $user_name"
